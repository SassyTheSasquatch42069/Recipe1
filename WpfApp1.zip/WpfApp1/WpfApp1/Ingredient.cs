﻿namespace WpfApp1
{
    public class Ingredient
    {
        public string IngredientName { get; }
        public int Calories { get; }
        public string FoodGroup { get; }

        public Ingredient(string ingredientName, int calories, string foodGroup)
        {
            IngredientName = ingredientName;
            Calories = calories;
            FoodGroup = foodGroup;
        }
    }
}
