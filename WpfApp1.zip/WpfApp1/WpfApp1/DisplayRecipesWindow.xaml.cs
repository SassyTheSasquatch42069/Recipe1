﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    public partial class DisplayRecipesWindow : Window
    {
        private List<Recipe> recipes;

        public DisplayRecipesWindow(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;

            // Display recipe names in alphabetical order
            cmbRecipes.ItemsSource = recipes.OrderBy(r => r.Name).Select(r => r.Name);
        }

        private void cmbRecipes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selectedRecipeName = cmbRecipes.SelectedItem as string;
            if (selectedRecipeName != null)
            {
                Recipe selectedRecipe = recipes.FirstOrDefault(r => r.Name == selectedRecipeName);
                if (selectedRecipe != null)
                {
                    // Display ingredients for the selected recipe
                    lvIngredients.ItemsSource = selectedRecipe.Ingredients;

                    // Display numbered steps for the selected recipe
                    lvSteps.ItemsSource = selectedRecipe.Steps.Select((step, index) => $"{index + 1}. {step}");

                    // Calculate total calories
                    int totalCalories = selectedRecipe.GetTotalCalories();
                    txtTotalCalories.Text = totalCalories.ToString();
                }
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }
    }
}
