﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes;

        public MainWindow()
        {
            InitializeComponent();
            recipes = new List<Recipe>();
        }

        private void CreateRecipe_Click(object sender, RoutedEventArgs e)
        {
            RecipeWindow recipeWindow = new RecipeWindow();
            if (recipeWindow.ShowDialog() == true)
            {
                recipes.Add(recipeWindow.Recipe);
            }
        }

        private void DisplayRecipes_Click(object sender, RoutedEventArgs e)
        {
            DisplayRecipesWindow displayRecipesWindow = new DisplayRecipesWindow(recipes);
            displayRecipesWindow.ShowDialog();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
