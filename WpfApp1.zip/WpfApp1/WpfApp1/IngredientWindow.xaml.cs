﻿using System.Windows;

namespace WpfApp1
{
    public partial class IngredientWindow : Window
    {
        public string IngredientName { get; private set; }
        public string Calories { get; private set; }
        public string FoodGroup { get; private set; }
        public string IngredientLabel { get; private set; }
        private bool isErrorOccurred;

        public IngredientWindow(int ingredientNumber)
        {
            InitializeComponent();
            IngredientLabel = $"Ingredient #{ingredientNumber}:";
            DataContext = this;

            Closing += IngredientWindow_Closing;
        }

        private void IngredientWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (isErrorOccurred)
            {
                e.Cancel = true;
                isErrorOccurred = false;
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            IngredientName = txtIngredientName.Text;
            Calories = txtCalories.Text;
            FoodGroup = cmbFoodGroup.Text;

            if (!IsValidString(IngredientName))
            {
                MessageBox.Show("Please enter a valid ingredient name (letters and spaces only).", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                ClearInputs();
                isErrorOccurred = true;
                return;
            }

            int calories;
            if (!int.TryParse(Calories, out calories))
            {
                MessageBox.Show("Please enter a valid number for the calories.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                ClearInputs();
                isErrorOccurred = true;
                return;
            }

            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void ClearInputs()
        {
            txtIngredientName.Text = string.Empty;
            txtCalories.Text = string.Empty;
            cmbFoodGroup.SelectedIndex = -1;
        }

        private bool IsValidString(string input)
        {
            foreach (char c in input)
            {
                if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                {
                    return false;
                }
            }

            return true;
        }
    }
}
