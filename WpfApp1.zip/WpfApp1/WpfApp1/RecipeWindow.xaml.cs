﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace WpfApp1
{
    public partial class RecipeWindow : Window
    {
        public Recipe Recipe { get; private set; }

        public RecipeWindow()
        {
            InitializeComponent();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string recipeName = txtRecipeName.Text;
                int numIngredients;

                if (!int.TryParse(txtNumIngredients.Text, out numIngredients))
                {
                    MessageBox.Show("Please enter a valid number for the number of ingredients.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int numSteps;

                if (!int.TryParse(txtNumSteps.Text, out numSteps))
                {
                    MessageBox.Show("Please enter a valid number for the number of steps.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // Validate recipe name
                if (string.IsNullOrWhiteSpace(recipeName))
                {
                    throw new ArgumentException("Recipe name cannot be empty.", "recipeName");
                }

                // Validate recipe name is a string
                if (!IsString(recipeName))
                {
                    throw new ArgumentException("Recipe name should contain only letters.", "recipeName");
                }

                List<Ingredient> ingredients = new List<Ingredient>();

                for (int i = 0; i < numIngredients; i++)
                {
                    IngredientWindow ingredientWindow = new IngredientWindow(i + 1);
                    if (ingredientWindow.ShowDialog() == true)
                    {
                        string ingredientName = ingredientWindow.IngredientName;
                        int calories;

                        if (!int.TryParse(ingredientWindow.Calories, out calories))
                        {
                            MessageBox.Show("Please enter a valid number for the calories.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }

                        string foodGroup = ingredientWindow.FoodGroup;

                        ingredients.Add(new Ingredient(ingredientName, calories, foodGroup));
                    }
                    else
                    {
                        // User canceled ingredient input, handle it if needed.
                        return;
                    }
                }

                List<string> steps = new List<string>();

                for (int i = 0; i < numSteps; i++)
                {
                    StepWindow stepWindow = new StepWindow(i + 1);
                    if (stepWindow.ShowDialog() == true)
                    {
                        string step = stepWindow.Step;
                        steps.Add(step);
                    }
                    else
                    {
                        // User canceled step input, handle it if needed.
                        return;
                    }
                }

                Recipe = new Recipe(recipeName, ingredients, steps);

                // Calculate total calories
                int totalCalories = Recipe.GetTotalCalories();

                // Check if the recipe exceeds 300 calories
                if (totalCalories > 300)
                {
                    MessageBox.Show("The recipe exceeds 300 calories!", "Alert", MessageBoxButton.OK, MessageBoxImage.Warning);
                }

                DialogResult = true;
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool IsString(string input)
        {
            foreach (char c in input)
            {
                if (!char.IsLetter(c))
                {
                    return false;
                }
            }

            return true;
        }
    }
}
