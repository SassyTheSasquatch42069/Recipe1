﻿using System.Collections.Generic;
using System.Linq;
using WpfApp1;

namespace WpfApp1
{
    public class Recipe
    {
        public string Name { get; }
        public List<Ingredient> Ingredients { get; }
        public List<string> Steps { get; }

        public Recipe(string name, List<Ingredient> ingredients, List<string> steps)
        {
            Name = name;
            Ingredients = ingredients;
            Steps = steps;
        }

        public int GetTotalCalories()
        {
            return Ingredients.Sum(i => i.Calories);
        }
    }
}
