﻿using System.Windows;

namespace WpfApp1
{
    public partial class StepWindow : Window
    {
        public string Step { get; private set; }
        public string StepLabel { get; private set; }

        public StepWindow(int stepNumber)
        {
            InitializeComponent();
            StepLabel = $"Step #{stepNumber}:";
            DataContext = this;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            Step = txtStep.Text;
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
